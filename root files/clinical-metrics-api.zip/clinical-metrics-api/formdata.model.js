const mongoose = require('mongoose');

const formSchema = new mongoose.Schema({
  facilityName: String,
  segment: String,
  month: String,
  year: String,
  apwResidents: Number,
  swlResidents: Number,
  unplannedSwlResidents: Number,
  fallsResidents: Number,
  fallsInjury: Number,
  census: Number,
  notes: String,
  timestamp: { type: Date, default: Date.now }
});

module.exports = mongoose.model('FormData', formSchema);
