const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();
const FormData = require('./formdata.model');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 10000;
const MONGO_URI = process.env.MONGO_URI;

mongoose.connect(MONGO_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

app.get('/entries', async (req, res) => {
  const entries = await FormData.find();
  res.json(entries);
});

app.post('/entries', async (req, res) => {
  const newEntry = new FormData(req.body);
  await newEntry.save();
  res.json(newEntry);
});

app.put('/entries/:id', async (req, res) => {
  const updated = await FormData.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

app.delete('/entries/:id', async (req, res) => {
  await FormData.findByIdAndDelete(req.params.id);
  res.json({ success: true });
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
